# Discord Bot – WoW Token EU Price

Este bot publica automáticamente cada hora el precio del Token de WoW en Europa en un canal de Discord.

## Variables de entorno necesarias (Railway):

- `DISCORD_BOT_TOKEN`
- `DISCORD_CHANNEL_ID`
